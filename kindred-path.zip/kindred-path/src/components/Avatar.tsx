"use client";

// "Wren" — an original illustrated guide drawn in SVG.
// Phase 3 replaces this with a professionally illustrated Rive character;
// the props (state + mouthOpen) stay the same so the swap is drop-in.

export type AvatarState = "idle" | "listening" | "thinking" | "talking";

export default function Avatar({ state, mouthOpen }: { state: AvatarState; mouthOpen: number }) {
  const open = state === "talking" ? Math.max(0, Math.min(1, mouthOpen)) : 0;
  const mouthH = 2 + open * 11;
  const browLift = state === "listening" ? -3 : state === "thinking" ? -2 : 0;
  const eyeShiftX = state === "thinking" ? 3 : 0;
  const eyeShiftY = state === "thinking" ? -3 : 0;

  return (
    <div className={`avatar-wrap avatar-${state}`} aria-hidden="true">
      <svg viewBox="0 0 240 260" className="avatar-svg">
        {/* listening halo */}
        <circle cx="120" cy="120" r="112" className="avatar-halo" />
        <g className="avatar-body">
          {/* shoulders / sweater */}
          <path d="M40 260 C44 205 80 186 120 186 C160 186 196 205 200 260 Z" fill="var(--sweater)" />
          <path d="M100 188 L120 214 L140 188" fill="none" stroke="var(--sweater-dark)" strokeWidth="5" strokeLinecap="round" />
          {/* neck */}
          <rect x="106" y="160" width="28" height="32" rx="12" fill="var(--skin-shadow)" />
          <g className="avatar-head">
            {/* back hair */}
            <path d="M58 112 C54 52 92 30 122 30 C158 30 188 54 184 112 C186 140 178 160 170 168 L72 168 C62 158 56 140 58 112 Z" fill="var(--hair)" />
            {/* face */}
            <ellipse cx="120" cy="112" rx="54" ry="60" fill="var(--skin)" />
            {/* ears */}
            <ellipse cx="66" cy="116" rx="8" ry="12" fill="var(--skin-shadow)" />
            <ellipse cx="174" cy="116" rx="8" ry="12" fill="var(--skin-shadow)" />
            {/* fringe */}
            <path d="M66 96 C70 58 100 46 124 48 C150 50 172 66 174 96 C160 80 140 72 118 74 C98 76 80 84 66 96 Z" fill="var(--hair)" />
            {/* brows */}
            <g transform={`translate(0 ${browLift})`}>
              <path d="M88 90 Q100 84 110 89" stroke="var(--hair)" strokeWidth="4" fill="none" strokeLinecap="round" />
              <path d="M130 89 Q140 84 152 90" stroke="var(--hair)" strokeWidth="4" fill="none" strokeLinecap="round" />
            </g>
            {/* eyes */}
            <g transform={`translate(${eyeShiftX} ${eyeShiftY})`}>
              <g className="avatar-blink">
                <ellipse cx="99" cy="108" rx="6" ry="7" fill="var(--ink)" />
                <ellipse cx="141" cy="108" rx="6" ry="7" fill="var(--ink)" />
                <circle cx="101" cy="105" r="2" fill="#fff" />
                <circle cx="143" cy="105" r="2" fill="#fff" />
              </g>
            </g>
            {/* cheeks */}
            <ellipse cx="86" cy="130" rx="10" ry="6" fill="var(--cheek)" opacity="0.55" />
            <ellipse cx="154" cy="130" rx="10" ry="6" fill="var(--cheek)" opacity="0.55" />
            {/* nose */}
            <path d="M120 112 Q116 124 121 126" stroke="var(--skin-line)" strokeWidth="2.5" fill="none" strokeLinecap="round" />
            {/* mouth */}
            {open > 0.05 ? (
              <g>
                <ellipse cx="120" cy={142 + mouthH / 4} rx={11 - open * 2} ry={mouthH / 2} fill="var(--mouth)" />
                <ellipse cx="120" cy={142 + mouthH / 2} rx={6} ry={Math.max(0.5, mouthH / 5)} fill="var(--tongue)" opacity="0.8" />
              </g>
            ) : (
              <path d="M107 140 Q120 150 133 140" stroke="var(--mouth)" strokeWidth="3.5" fill="none" strokeLinecap="round" />
            )}
          </g>
        </g>
      </svg>
      {state === "thinking" && (
        <div className="avatar-dots" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
      )}
    </div>
  );
}
